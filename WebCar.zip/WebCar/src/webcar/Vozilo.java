package webcar;

import java.util.ArrayList;


public class Vozilo {
    private int ID;
    private String Naziv;
    private String Godina;
    private String RegistracijskaOznaka;
    private String KorisnikEmail;

    public Vozilo(){}
    public Vozilo(int ID, String Naziv, String Godina, String RegistracijskaOznaka, String KorisnikEmail) {
        super();
        this.ID = ID;
        this.Naziv = Naziv;
        this.Godina = Godina;
        this.RegistracijskaOznaka = RegistracijskaOznaka;
        this.KorisnikEmail=KorisnikEmail;
    }

    public void setKorisnikEmail(String KorisnikEmail) {
        this.KorisnikEmail = KorisnikEmail;
    }

    public String getKorisnikEmail() {
        return KorisnikEmail;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID() {
        return ID;
    }

    public void setNaziv(String Naziv) {
        this.Naziv = Naziv;
    }

    public String getNaziv() {
        return Naziv;
    }

    public void setGodina(String Godina) {
        this.Godina = Godina;
    }

    public String getGodina() {
        return Godina;
    }

    public void setRegistracijskaOznaka(String RegistracijskaOznaka) {
        this.RegistracijskaOznaka = RegistracijskaOznaka;
    }

    public String getRegistracijskaOznaka() {
        return RegistracijskaOznaka;
    }
    public ArrayList<String> toList() {
        ArrayList<String> temp = new ArrayList<String>();
        temp.add("" + this.ID);
        temp.add(this.Naziv);
        temp.add("" + this.Godina);
        temp.add("" + this.RegistracijskaOznaka);
        temp.add("" + this.KorisnikEmail);
        return temp;
    }
    public String toString() {
        return this.Naziv;
    }

}
