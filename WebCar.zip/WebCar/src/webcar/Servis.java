package webcar;

import java.util.ArrayList;


public class Servis {
    
    private int IDservis;
    private String NazivServisa;
    private String Adresa;
    private String Kontakt;
    private String Vlasnik;

    public Servis(){}
    public Servis(int IDservis, String NazivServisa, String Adresa, String Kontakt, String Vlasnik ) {
        this.IDservis = IDservis;
        this.NazivServisa = NazivServisa;
        this.Adresa = Adresa;
        this.Kontakt = Kontakt;
        this.Vlasnik = Vlasnik;
    }


    public void setIDservis(int IDservis) {
        this.IDservis = IDservis;
    }

    public int getIDservis() {
        return IDservis;
    }

    public void setNazivServisa(String NazivServisa) {
        this.NazivServisa = NazivServisa;
    }

    public String getNazivServisa() {
        return NazivServisa;
    }

    public void setAdresa(String Adresa) {
        this.Adresa = Adresa;
    }

    public String getAdresa() {
        return Adresa;
    }

    public void setKontakt(String Kontakt) {
        this.Kontakt = Kontakt;
    }

    public String getKontakt() {
        return Kontakt;
    }

    public void setVlasnik(String Vlasnik) {
        this.Vlasnik = Vlasnik;
    }

    public String getVlasnik() {
        return Vlasnik;
    }

    public ArrayList<String> toList() {
        ArrayList<String> temp = new ArrayList<String>();
        temp.add("" + this.IDservis);
        temp.add(this.NazivServisa);
        temp.add("" + this.Kontakt);
        temp.add("" + this.Vlasnik);
        temp.add("" + this.Adresa);
        return temp;
    }
    public String toString() {
        return this.NazivServisa;
    }
}
