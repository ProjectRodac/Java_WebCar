package webcar;

import java.util.ArrayList;

public class Korisnik {
    private String Email;
    private String Ime;
    private String Prezime;
    private String Lozinka;

    public Korisnik(){}
    public Korisnik(String Email, String Ime, String Prezime, String Lozinka) {
        this.Email=Email;
        this.Ime=Ime;
        this.Prezime=Prezime;
        this.Lozinka=Lozinka;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getEmail() {
        return Email;
    }

    public void setIme(String Ime) {
        this.Ime = Ime;
    }

    public String getIme() {
        return Ime;
    }

    public void setPrezime(String Prezime) {
        this.Prezime = Prezime;
    }

    public String getPrezime() {
        return Prezime;
    }

    public void setLozinka(String Lozinka) {
        this.Lozinka = Lozinka;
    }

    public String getLozinka() {
        return Lozinka;
    }

    
    public ArrayList<String> toList() {
        ArrayList<String> temp = new ArrayList<String>();
        temp.add("" + this.Email);
        temp.add(this.Ime);
        temp.add("" + this.Prezime);
        temp.add("" + this.Lozinka);
        return temp;
    }
    public String toString() {
        return this.Email;
    }
}
