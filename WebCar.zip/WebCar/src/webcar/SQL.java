package webcar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.Date;

public class SQL {
    

    
        private static String email;
        private static String db="jdbc:mysql://ucka.veleri.hr:3306/jbenic";
        private static String user="jbenic";
        private static String pass="11";
    public static boolean unosServisa(String naziv, String adresa, String kontakt, String vlasnik) {
            //Spremanje u bazu

            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(db,user, pass);//podatci za spajanje na bazu

                Statement stmt = conn.createStatement();
                String sql = 
                    "INSERT INTO servis (naziv, adresa, kontakt, vlasnik) VALUES ('" + naziv + "','" + adresa + "','" + kontakt + "','" + vlasnik+"')";
                System.out.println(sql);

                stmt.executeUpdate(sql);

                conn.close();

            } catch (SQLException ex) {

                System.out.println("SQL gre�ska " + ex.toString());
                return false;

            } catch (Exception ex) {
                System.out.println("Greska kod drivera  " + ex.toString());
                return false;
            }
            return true;

    }
    public static ArrayList dohvatServisa() {
        //Spremanje u bazu

        ArrayList<Servis> al = new ArrayList<Servis>();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user, pass);

            Statement stmt = conn.createStatement();
            String sql ="SELECT * FROM servis"; 
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int IDservis=rs.getInt("IDservis");
                String naziv = rs.getString("naziv");
                String adresa = rs.getString("adresa");
                String kontakt = rs.getString("kontakt");
                String vlasnik = rs.getString("vlasnik");
                Servis s = new Servis(IDservis, naziv, adresa,kontakt,vlasnik);
                al.add(s);

            }
            conn.close();

        } catch (SQLException ex) {

            System.out.println("SQL gre�ska " + ex.toString());
            return null;

        } catch (Exception ex) {
            System.out.println("Greska kod drivera  " + ex.toString());
            return null;
        }
        return al;

    }
    static void izmjeniServis(int idservis, String naziv, String adresa, String kontakt, String vlasnik) {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user,pass);
            Statement stmt = conn.createStatement();
            String sql = "UPDATE servis SET naziv= '"+naziv+"',adresa= '"+adresa+"',kontakt= '"+kontakt+"',vlasnik= '"+vlasnik+"' WHERE idservis= " + idservis + ";";
            System.out.println(sql);
            stmt.executeUpdate(sql);
            conn.close();
        } catch (ClassNotFoundException ex) {
            System.out.println("Greska, nije naden driver" + ex.toString());
            
        } catch (SQLException ex) {
            System.out.println("SQL greska" + ex.toString());
            
        } catch (Exception ex) {
            System.out.println("Neka greska" + ex.toString());
            
        }
        
    }
    public static boolean prijava(String Email, String Lozinka){
      try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user,pass);
            Statement stmt = conn.createStatement();
        String sql = "SELECT count(*)AS rowcount FROM korisnik WHERE email='" + Email + "'" + "AND lozinka='" + Lozinka + "'";
        System.out.println(sql);
        ResultSet rs = stmt.executeQuery(sql);
        rs.next();
        int count = rs.getInt("rowcount");
          if (count==1){
              email=Email;
              return true;
          }
          else
            return false;
        } catch (ClassNotFoundException ex) {
            System.out.println("Greska, nije naden driver" + ex.toString());
            
        } catch (SQLException ex) {
            System.out.println("SQL greska" + ex.toString());
            
        } catch (Exception ex) {
            System.out.println("Neka greska" + ex.toString());
            
        }
    return false;
    }
    public static boolean registracijaKorisnika(String Email, String Ime, String Prezime, String Lozinka) {
        //Spremanje u bazu

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user, pass);//podatci za spajanje na bazu

            Statement stmt = conn.createStatement();
            String sql = 
                "INSERT INTO korisnik (email, ime, prezime, lozinka) VALUES ('" + Email + "','" + Ime + "','" + Prezime + "','" + Lozinka+"')";
            System.out.println(sql);

            stmt.executeUpdate(sql);

            conn.close();

        } catch (SQLException ex) {

            System.out.println("SQL gre�ska " + ex.toString());
            return false;

        } catch (Exception ex) {
            System.out.println("Greska kod drivera  " + ex.toString());
            return false;
        }
        return true;

    }
    public static boolean UnosBenzinskePostaje(String NazivBenzinskePostaje, String AdresaBenzinskePostaje) {
        //Spremanje u bazu

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user, pass);//podatci za spajanje na bazu

            Statement stmt = conn.createStatement();
            String sql = 
                "INSERT INTO benzinska_postaja (naziv, adresa) VALUES ('" + NazivBenzinskePostaje + "','" + AdresaBenzinskePostaje + "')";
            System.out.println(sql);

            stmt.executeUpdate(sql);

            conn.close();

        } catch (SQLException ex) {

            System.out.println("SQL gre�ska " + ex.toString());
            return false;

        } catch (Exception ex) {
            System.out.println("Greska kod drivera  " + ex.toString());
            return false;
        }
        return true;

    }
    public static ArrayList dohvatBenzinskePostaje() {
        //Spremanje u bazu

        ArrayList<BenzinskaPostaja> al = new ArrayList<BenzinskaPostaja>();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user, pass);

            Statement stmt = conn.createStatement();
            String sql = "SELECT benzinska_postaja.idbenzinska_postaja,benzinska_postaja.adresa,benzinska_postaja.naziv, toceno_gorivo.benzinska_postaja_idbenzinska_postaja, vozilo.idvozilo FROM benzinska_postaja" + 
            " LEFT JOIN toceno_gorivo" + 
            " ON benzinska_postaja.idbenzinska_postaja=toceno_gorivo.benzinska_postaja_idbenzinska_postaja" + 
            " LEFT JOIN vozilo" + 
            " ON vozilo.idvozilo=toceno_gorivo.vozilo_idvozilo " + 
            " WHERE vozilo.korisnik_email='"+email+"' ;";
            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int idbenzinska_postaja=rs.getInt("idbenzinska_postaja");
                String naziv = rs.getString("naziv");
                String adresa = rs.getString("adresa");
                BenzinskaPostaja b = new BenzinskaPostaja(idbenzinska_postaja, naziv, adresa);
                al.add(b);

            }
            conn.close();

        } catch (SQLException ex) {

            System.out.println("SQL gre�ska " + ex.toString());
            return null;

        } catch (Exception ex) {
            System.out.println("Greska kod drivera  " + ex.toString());
            return null;
        }
        return al;

    }
    static void brisiBenzinskuPostaju(Integer id) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(db,user, pass);
                Statement stmt = conn.createStatement();
                String sql = "DELETE FROM benzinska_postaja WHERE idbenzinska_postaja= "  + id + ";";
                System.out.println(sql);
                stmt.executeUpdate(sql);
                conn.close();
            } catch (ClassNotFoundException ex) {
                System.out.println("Greska, nije naden driver" + ex.toString());
            } catch (SQLException ex) {
                System.out.println("SQL greska" + ex.toString());
            } catch (Exception ex) {
                System.out.println("Neka greska" + ex.toString());
            }
        }
    public static boolean unosVozila(String naziv, String godina, String registracijskaOznaka, String KorisnikEmail) {
            //Spremanje u bazu

            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(db,user, pass);//podatci za spajanje na bazu

                Statement stmt = conn.createStatement();
                String sql = 
                    "INSERT INTO vozilo (naziv, godina, registracijska_oznaka, korisnik_email) VALUES ('" + naziv + "','" + godina + "','" + registracijskaOznaka + "','" + email + "')";
                System.out.println(sql);

                stmt.executeUpdate(sql);

                conn.close();

            } catch (SQLException ex) {

                System.out.println("SQL gre�ska " + ex.toString());
                return false;

            } catch (Exception ex) {
                System.out.println("Greska kod drivera  " + ex.toString());
                return false;
            }
            return true;

    }
    public static ArrayList dohvatVozila() {
      
        ArrayList<Vozilo> al = new ArrayList<Vozilo>();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user, pass);

            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM vozilo WHERE korisnik_email= '"+email+"';";
            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int ID=rs.getInt("idvozilo");
                String Naziv = rs.getString("naziv");
                String Godina = rs.getString("godina");
                String Registracijska_oznaka = rs.getString("registracijska_oznaka");
                String KorisnikEmail = rs.getString("korisnik_email");
                Vozilo v = new Vozilo(ID, Naziv, Godina, Registracijska_oznaka, KorisnikEmail);
                al.add(v);

            }
            conn.close();

        } catch (SQLException ex) {

            System.out.println("SQL gre�ska " + ex.toString());
            return null;

        } catch (Exception ex) {
            System.out.println("Greska kod drivera  " + ex.toString());
            return null;
        }
        return al;

    }
    static void brisiVozilo(Integer id) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(db,user, pass);
                Statement stmt = conn.createStatement();
                String sql = "DELETE FROM vozilo WHERE idvozilo= "  + id + ";";
                System.out.println(sql);
                stmt.executeUpdate(sql);
                conn.close();
            } catch (ClassNotFoundException ex) {
                System.out.println("Greska, nije naden driver" + ex.toString());
            } catch (SQLException ex) {
                System.out.println("SQL greska" + ex.toString());
            } catch (Exception ex) {
                System.out.println("Neka greska" + ex.toString());
            }
        }
    public static boolean unosPopravka(String Datum, String Napomena, int IDVozila, int IDServis) {
            //Spremanje u bazu

            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(db,user, pass);//podatci za spajanje na bazu

                Statement stmt = conn.createStatement();
                String sql = 
                    "INSERT INTO popravak (datum, napomena, vozilo_idvozilo, servis_idservis) VALUES ('" + Datum + "','" + Napomena + "','" + IDVozila + "','" + IDServis+"')";
                System.out.println(sql);

                stmt.executeUpdate(sql);

                conn.close();

            } catch (SQLException ex) {

                System.out.println("SQL gre�ska " + ex.toString());
                return false;

            } catch (Exception ex) {
                System.out.println("Greska kod drivera  " + ex.toString());
                return false;
            }
            return true;

    }
    public static boolean unosGoriva(String toceno_l, String toceno_kn, String datum, String vrstaGoriva ,int IDvozilo, int IDBenzin) {
            //Spremanje u bazu

            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(db,user, pass);//podatci za spajanje na bazu

                Statement stmt = conn.createStatement();
                String sql = 
                    "INSERT INTO toceno_gorivo (toceno_l, toceno_kn, datum, vrsta_goriva,vozilo_idvozilo,benzinska_postaja_idbenzinska_postaja) VALUES ('" + toceno_l + "','" + toceno_kn + "','" + datum + "','" + vrstaGoriva+"','" + IDvozilo + "','" + IDBenzin + "')";
                System.out.println(sql);

                stmt.executeUpdate(sql);

                conn.close();

            } catch (SQLException ex) {

                System.out.println("SQL gre�ska " + ex.toString());
                return false;

            } catch (Exception ex) {
                System.out.println("Greska kod drivera  " + ex.toString());
                return false;
            }
            return true;

    } 
    public static ArrayList dohvatPopravaka() {
        //Spremanje u bazu

        ArrayList<Popravak> al = new ArrayList<Popravak>();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user, pass);

            Statement stmt = conn.createStatement();
            String sql = "SELECT popravak.datum,popravak.idpopravak,popravak.napomena,(servis.naziv) as nazivServisa,(vozilo.naziv) as nazivVozila FROM popravak" + 
            " LEFT JOIN vozilo" + 
            " ON popravak.vozilo_idvozilo=vozilo.idvozilo  " + 
            " LEFT JOIN servis" + 
            " ON servis.idservis=popravak.servis_idservis " + 
            " WHERE vozilo.korisnik_email='"+email+"' ;";
            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int IDpopravka=rs.getInt("idpopravak");
                Date Datum = rs.getDate("datum");
                String Napomena = rs.getString("napomena");
                String IDServis = rs.getString("nazivServisa");
                String IDVozilo = rs.getString("nazivVozila");
                Popravak p = new Popravak(IDpopravka, Datum, Napomena,IDServis,IDVozilo);
                al.add(p);

            }
            conn.close();

        } catch (SQLException ex) {

            System.out.println("SQL gre�ska " + ex.toString());
            return null;

        } catch (Exception ex) {
            System.out.println("Greska kod drivera  " + ex.toString());
            return null;
        }
        return al;

    }
    public static ArrayList dohvatTocenogGoriva() {
        //Spremanje u bazu

        ArrayList<TocenoGorivo> al = new ArrayList<TocenoGorivo>();
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user, pass);

            Statement stmt = conn.createStatement();
            String sql = "SELECT toceno_gorivo.idtoceno_gorivo, toceno_gorivo.toceno_l,toceno_gorivo.toceno_kn,toceno_gorivo.datum,toceno_gorivo.vrsta_goriva,(vozilo.naziv) as nazivVozila,(benzinska_postaja.naziv) as nazivBenzinskePostaje FROM toceno_gorivo" + 
            " LEFT JOIN vozilo " + 
            " ON toceno_gorivo.vozilo_idvozilo=vozilo.idvozilo " + 
            " LEFT JOIN benzinska_postaja " + 
            " ON benzinska_postaja.idbenzinska_postaja=toceno_gorivo.benzinska_postaja_idbenzinska_postaja " + 
            " WHERE vozilo.korisnik_email='"+email+"' ;";
            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                int IDtocenog_goriva=rs.getInt("idtoceno_gorivo");
                String toceno_l = rs.getString("toceno_l");
                String toceno_kn = rs.getString("toceno_kn");
                Date Datum = rs.getDate("datum");
                String vrsta_goriva = rs.getString("vrsta_goriva");
                String NazivVozila =rs.getString("nazivVozila");
                String nazivBenzinskePostaje =rs.getString("nazivBenzinskePostaje");
                
                TocenoGorivo t = new TocenoGorivo(IDtocenog_goriva, toceno_l, toceno_kn,Datum,vrsta_goriva,NazivVozila,nazivBenzinskePostaje);
                al.add(t);

            }
            conn.close();

        } catch (SQLException ex) {

            System.out.println("SQL gre�ska " + ex.toString());
            return null;

        } catch (Exception ex) {
            System.out.println("Greska kod drivera  " + ex.toString());
            return null;
        }
        return al;

    }
    static void brisiTocenoGorivo(Integer id) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                Connection conn = DriverManager.getConnection(db,user, pass);
                Statement stmt = conn.createStatement();
                String sql = "DELETE FROM toceno_gorivo WHERE idtoceno_gorivo= "  + id + ";";
                System.out.println(sql);
                stmt.executeUpdate(sql);
                conn.close();
            } catch (ClassNotFoundException ex) {
                System.out.println("Greska, nije naden driver" + ex.toString());
            } catch (SQLException ex) {
                System.out.println("SQL greska" + ex.toString());
            } catch (Exception ex) {
                System.out.println("Neka greska" + ex.toString());
            }
        }
    static void izmjeniTocenoGorivo(int idtoceno_gorivo, String toceno_l, String toceno_kn, String vrsta_goriva) {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db,user,pass);
            Statement stmt = conn.createStatement();
            String sql = "UPDATE toceno_gorivo SET toceno_l= '"+toceno_l+"',toceno_kn= '"+toceno_kn+"',vrsta_goriva= '"+vrsta_goriva+"' WHERE idtoceno_gorivo= " + idtoceno_gorivo + ";";
            System.out.println(sql);
            stmt.executeUpdate(sql);
            conn.close();
        } catch (ClassNotFoundException ex) {
            System.out.println("Greska, nije naden driver" + ex.toString());
            
        } catch (SQLException ex) {
            System.out.println("SQL greska" + ex.toString());
            
        } catch (Exception ex) {
            System.out.println("Neka greska" + ex.toString());
            
        }
        
    }
    static void brisiPopravak(Integer id) {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "DELETE FROM popravak WHERE idpopravak= " + id + ";";
            System.out.println(sql);
            stmt.executeUpdate(sql);
            conn.close();
        } catch (ClassNotFoundException ex) {
            System.out.println("Greska, nije naden driver" + ex.toString());
        } catch (SQLException ex) {
            System.out.println("SQL greska" + ex.toString());
        } catch (Exception ex) {
            System.out.println("Neka greska" + ex.toString());
        }
    }
    static void brisiServis(Integer id) {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(db, user, pass);
            Statement stmt = conn.createStatement();
            String sql = "DELETE FROM servis WHERE idservis= " + id + ";";
            System.out.println(sql);
            stmt.executeUpdate(sql);
            conn.close();
        } catch (ClassNotFoundException ex) {
            System.out.println("Greska, nije naden driver" + ex.toString());
        } catch (SQLException ex) {
            System.out.println("SQL greska" + ex.toString());
        } catch (Exception ex) {
            System.out.println("Neka greska" + ex.toString());
        }
    }
}
