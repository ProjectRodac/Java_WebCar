package webcar;

import java.util.ArrayList;
import java.util.Date;


public class TocenoGorivo {
    private int IDGorivo;
    private String TocenoL;
    private String TocenoKn;
    private Date Datum;
    private String VrstaGoriva;
    private String NazivVozila;
    private String NazivBenzinskePostaje;

    public TocenoGorivo(){}
    public TocenoGorivo(int IDGorivo, String TocenoL, String TocenoKn, Date Datum, String VrstaGoriva, String NazivVozila,String NazivBenzinskePostaje ) {
        this.IDGorivo = IDGorivo;
        this.TocenoL = TocenoL;
        this.TocenoKn = TocenoKn;
        this.Datum= Datum;
        this.VrstaGoriva= VrstaGoriva;
        this.NazivVozila=NazivVozila;
        this.NazivBenzinskePostaje=NazivBenzinskePostaje;
    }


    public void setIDGorivo(int IDGorivo) {
        this.IDGorivo = IDGorivo;
    }

    public int getIDGorivo() {
        return IDGorivo;
    }

    

    public void setDatum(Date Datum) {
        this.Datum = Datum;
    }

    public Date getDatum() {
        return Datum;
    }


    public void setNazivVozila(String NazivVozila) {
        this.NazivVozila = NazivVozila;
    }

    public String getNazivVozila() {
        return NazivVozila;
    }

    public void setNazivBenzinskePostaje(String NazivBenzinskePostaje) {
        this.NazivBenzinskePostaje = NazivBenzinskePostaje;
    }

    public String getNazivBenzinskePostaje() {
        return NazivBenzinskePostaje;
    }

    public void setTocenoL(String TocenoL) {
        this.TocenoL = TocenoL;
    }

    public String getTocenoL() {
        return TocenoL;
    }

    public void setTocenoKn(String TocenoKn) {
        this.TocenoKn = TocenoKn;
    }

    public String getTocenoKn() {
        return TocenoKn;
    }

    public void setVrstaGoriva(String VrstaGoriva) {
        this.VrstaGoriva = VrstaGoriva;
    }

    public String getVrstaGoriva() {
        return VrstaGoriva;
    }
    public ArrayList<String> toList() {
        ArrayList<String> temp = new ArrayList<String>();
        temp.add("" + this.IDGorivo);
        temp.add(""+this.TocenoL);
        temp.add("" + this.TocenoKn);
        temp.add("" + this.Datum);
        temp.add("" + this.VrstaGoriva);
        temp.add("" + this.NazivVozila);
        temp.add("" + this.NazivBenzinskePostaje);
        return temp;
    }
    public String toString() {
        return this.VrstaGoriva;
    }
}
