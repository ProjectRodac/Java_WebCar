package webcar;

import java.util.ArrayList;


public class BenzinskaPostaja {
    
    private int IDbenzinskePostaje;
    private String NazivBenzinskePostaje;
    private String AdresaBenzinskePostaje;

    public BenzinskaPostaja(){}
    public BenzinskaPostaja(int IDbenzinskePostaje, String NazivBenzinskePostaje, String AdresaBenzinskePostaje ) {
        this.IDbenzinskePostaje = IDbenzinskePostaje;
        this.NazivBenzinskePostaje = NazivBenzinskePostaje;
        this.AdresaBenzinskePostaje = AdresaBenzinskePostaje;
     
    }

    public void setIDbenzinskePostaje(int IDbenzinskePostaje) {
        this.IDbenzinskePostaje = IDbenzinskePostaje;
    }

    public int getIDbenzinskePostaje() {
        return IDbenzinskePostaje;
    }

    public void setNazivBenzinskePostaje(String NazivBenzinskePostaje) {
        this.NazivBenzinskePostaje = NazivBenzinskePostaje;
    }

    public String getNazivBenzinskePostaje() {
        return NazivBenzinskePostaje;
    }

    public void setAdresaBenzinskePostaje(String AdresaBenzinskePostaje) {
        this.AdresaBenzinskePostaje = AdresaBenzinskePostaje;
    }

    public String getAdresaBenzinskePostaje() {
        return AdresaBenzinskePostaje;
    }
    public ArrayList<String> toList() {
        ArrayList<String> temp = new ArrayList<String>();
        temp.add("" + this.IDbenzinskePostaje);
        temp.add(this.NazivBenzinskePostaje);
        temp.add("" + this.AdresaBenzinskePostaje);
        return temp;
    }
    public String toString() {
        return this.NazivBenzinskePostaje;
    }
}
