package webcar;

import java.util.ArrayList;
import java.util.Date;


public class Popravak {
    
    private int IDpopravka;
    private Date Datum;
    private String Napomena;
    private String NazivServisa;
    private String NazivVozila;
    

    public Popravak(){}
    public Popravak(int IDpopravka, Date Datum, String Napomena,String NazivServisa, String NazivVozila) {
        this.IDpopravka = IDpopravka;
        this.Datum = Datum;
        this.Napomena = Napomena;
        this.NazivServisa = NazivServisa;
        this.NazivVozila = NazivVozila;
       
    }

    public void setDatum(Date Datum) {
        this.Datum = Datum;
    }

    public Date getDatum() {
        return Datum;
    }


    public void setNazivServisa(String NazivServisa) {
        this.NazivServisa = NazivServisa;
    }

    public String getNazivServisa() {
        return NazivServisa;
    }

    public void setNazivVozila(String NazivVozila) {
        this.NazivVozila = NazivVozila;
    }

    public String getNazivVozila() {
        return NazivVozila;
    }

    public void setIDpopravka(int IDpopravka) {
        this.IDpopravka = IDpopravka;
    }

    public int getIDpopravka() {
        return IDpopravka;
    }


    public void setNapomena(String Napomena) {
        this.Napomena = Napomena;
    }

    public String getNapomena() {
        return Napomena;
    }
    public ArrayList<String> toList() {
        ArrayList<String> temp = new ArrayList<String>();
        temp.add("" + this.IDpopravka);
        temp.add(""+this.Datum);
        temp.add("" + this.Napomena);
        temp.add("" + this.NazivServisa);
        temp.add("" + this.NazivVozila);
        return temp;
    }
    public String toString() {
        return this.Napomena;
    }
}
